## colorscripts
These are various color testing scripts that I've collected across the net.
