 ${redf} █         █   ${greenf}█         █   ${yellowf}█         █   ${bluef}█         █   ${purplef}█         █   ${cyanf}█         █
 ${redf} █   ▄▄▄   █   ${greenf}█   ▄▄▄   █   ${yellowf}█   ▄▄▄   █   ${bluef}█   ▄▄▄   █   ${purplef}█   ▄▄▄   █   ${cyanf}█   ▄▄▄   █
 ${redf} █▄▄██▀██▄▄█   ${greenf}█▄▄██▀██▄▄█   ${yellowf}█▄▄██▀██▄▄█   ${bluef}█▄▄██▀██▄▄█   ${purplef}█▄▄██▀██▄▄█   ${cyanf}█▄▄██▀██▄▄█
 ${redf} █▀▀█████▀▀█   ${greenf}█▀▀█████▀▀█   ${yellowf}█▀▀█████▀▀█   ${bluef}█▀▀█████▀▀█   ${purplef}█▀▀█████▀▀█   ${cyanf}█▀▀█████▀▀█
 ${redf} █   ▀▀▀   █   ${greenf}█   ▀▀▀   █   ${yellowf}█   ▀▀▀   █   ${bluef}█   ▀▀▀   █   ${purplef}█   ▀▀▀   █   ${cyanf}█   ▀▀▀   █
 ${redf} █         █   ${greenf}█         █   ${yellowf}█         █   ${bluef}█         █   ${purplef}█         █   ${cyanf}█         █
 ${boldon}
 ${redf} █         █   ${greenf}█         █   ${yellowf}█         █   ${bluef}█         █   ${purplef}█         █   ${cyanf}█         █
 ${redf} █   ▄▄▄   █   ${greenf}█   ▄▄▄   █   ${yellowf}█   ▄▄▄   █   ${bluef}█   ▄▄▄   █   ${purplef}█   ▄▄▄   █   ${cyanf}█   ▄▄▄   █
 ${redf} █▄▄██▀██▄▄█   ${greenf}█▄▄██▀██▄▄█   ${yellowf}█▄▄██▀██▄▄█   ${bluef}█▄▄██▀██▄▄█   ${purplef}█▄▄██▀██▄▄█   ${cyanf}█▄▄██▀██▄▄█
 ${redf} █▀▀█████▀▀█   ${greenf}█▀▀█████▀▀█   ${yellowf}█▀▀█████▀▀█   ${bluef}█▀▀█████▀▀█   ${purplef}█▀▀█████▀▀█   ${cyanf}█▀▀█████▀▀█
 ${redf} █   ▀▀▀   █   ${greenf}█   ▀▀▀   █   ${yellowf}█   ▀▀▀   █   ${bluef}█   ▀▀▀   █   ${purplef}█   ▀▀▀   █   ${cyanf}█   ▀▀▀   █
 ${redf} █         █   ${greenf}█         █   ${yellowf}█         █   ${bluef}█         █   ${purplef}█         █   ${cyanf}█         █
 ${reset}
 ****************** Building blocks: █ ▓ ▒ ░ ▄ ▀ ▐ ▌ ●  ═ ║ ╔ ╦ ╗ ╚ ╩ ╝ ■ ▬ ▲ ▼ ◄ ►