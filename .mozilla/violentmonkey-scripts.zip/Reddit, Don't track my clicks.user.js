// ==UserScript==
// @name Reddit, Don't track my clicks
// @namespace Block Reddit from tracking outbound links
// @description Block tracking outbound links officially announced by Reddit https://goo.gl/XtHKEX
// @author SMed79
// @version 1.1
// @encoding utf-8
// @license https://creativecommons.org/licenses/by-nc-sa/4.0/
// @icon http://i.imgur.com/VMwvJvO.png
// @twitterURL https://twitter.com/SMed79
// @contactURL http://tinyurl.com/contact-smed79
// @supportURL https://greasyfork.org/fr/scripts/18058-block-reddit-from-tracking-outbound-links/feedback
// @match *://*.reddit.com/*
// @grant none
// ==/UserScript==

/*=====================================================
Credit to OperaSona
https://www.reddit.com/r/privacy/comments/4aqdg0/reddit_started_tracking_the_links_we_click_heres/
======================================================*/

var a_col = document.getElementsByTagName('a');
var a, reddit_tracking_url;
for(var i = 0; i < a_col.length; i++) {
a = a_col[i];
reddit_tracking_url = a.getAttribute('data-href-url');
if(reddit_tracking_url) a.setAttribute('data-outbound-url', reddit_tracking_url);
}
